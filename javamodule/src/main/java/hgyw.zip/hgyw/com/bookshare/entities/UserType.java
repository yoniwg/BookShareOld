package hgyw.com.bookshare.entities;

import java.util.NoSuchElementException;

/**
 * Created by Yoni on 3/15/2016.
 */
public enum UserType{
    CUSTOMER, SUPPLIER, GUEST
}
