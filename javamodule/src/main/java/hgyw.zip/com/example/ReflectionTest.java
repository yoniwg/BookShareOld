package com.example;

import hgyw.com.bookshare.entities.Book;
import hgyw.com.bookshare.entities.BookSupplier;
import hgyw.com.bookshare.entities.IdReference;
import hgyw.com.bookshare.entities.Supplier;
import hgyw.com.bookshare.entities.reflection.EntityReflection;

/**
 * Created by haim7 on 04/05/2016.
 */
public class ReflectionTest {
    static class MyClass {
        int age;
        double weidgh;
        String name;

        public int getAge() {
            return age;
        }

        public double getWeidgh() {
            return weidgh;
        }

        public void setWeidgh(double weidgh) {
            this.weidgh = weidgh;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    public static void main(String[] argv) {

        //System.out.println(Arrays.toString(MyClass.class.getDeclaredFields()));
        //System.out.println(PropertiesReflection.getPropertiesMap(MyClass.class));

        BookSupplier bookSupplier = new BookSupplier();
        bookSupplier.setBookId(222);
        bookSupplier.setSupplierId(333);
        System.out.println(
            EntityReflection.predicateEntityReferTo(BookSupplier.class, IdReference.of(Book.class, 222), IdReference.of(Supplier.class, 3233)).test(bookSupplier)
        );
    }


}
